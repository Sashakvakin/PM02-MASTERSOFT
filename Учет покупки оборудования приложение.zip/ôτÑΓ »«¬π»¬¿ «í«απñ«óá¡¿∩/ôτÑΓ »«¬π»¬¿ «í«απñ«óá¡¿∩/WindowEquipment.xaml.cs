﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Учет_покупки_оборудования
{
    /// <summary>
    /// Логика взаимодействия для WindowEquipment.xaml
    /// </summary>
    public partial class WindowEquipment : Window
    {
        public WindowEquipment()
        {
            InitializeComponent();
            LoadEquipment();
            LoadTypes();
        }

        private void Vihod_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        // Загрузка данных об оборудовании
        private void LoadEquipment()
        {
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                dgAllEquipment.ItemsSource = connection.Оборудование
                    .Select(o => new
                    {
                        Id = o.id_оборудования, // Идентификатор
                        Наименование = o.наименование, // Наименование
                        Тип_оборудования = o.Тип_оборудования.наименование // Тип оборудования
                    })
                    .ToList();
            }
        }

        // Загрузка типов оборудования для ComboBox
        private void LoadTypes()
        {
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                сbType.ItemsSource = connection.Тип_оборудования.ToList();
                сbType.DisplayMemberPath = "наименование";
                сbType.SelectedValuePath = "id_типа_оборудования";
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // Получаем данные из TextBox и ComboBox
            string name = tbName.Text;
            int? typeId = сbType.SelectedValue as int?;

            // Проверка ввода
            if (string.IsNullOrEmpty(name) || typeId == null)
            {
                MessageBox.Show("Заполните все поля.");
                return;
            }

            // Получение максимального существующего id_оборудования
            int maxId;
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                maxId = connection.Оборудование.Max(o => o.id_оборудования);
            }

            // Вычисление нового id_оборудования
            int newId = maxId + 1;

            // Добавление нового оборудования в базу данных
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                Оборудование newEquipment = new Оборудование()
                {
                    id_оборудования = newId,
                    id_типа_оборудования = typeId.Value,
                    наименование = name
                };

                connection.Оборудование.Add(newEquipment);
                connection.SaveChanges();

                // Обновление данных в DataGrid
                LoadEquipment();

                // Очистка полей
                tbName.Text = "";
                сbType.SelectedItem = null;
            }
        }

        // Удаление выбранного оборудования
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            // Получение выбранной строки из DataGrid
            if (dgAllEquipment.SelectedItem != null)
            {
                var selectedEquipment = dgAllEquipment.SelectedItem as dynamic; // Используем dynamic для удобства доступа к данным
                int equipmentId = selectedEquipment.Id;

                // Подтверждение удаления
                if (MessageBox.Show("Удалить оборудование?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    // Удаление оборудования из базы данных
                    using (УчетПОEntities connection = new УчетПОEntities())
                    {
                        var equipmentToDelete = connection.Оборудование.Find(equipmentId);
                        if (equipmentToDelete != null)
                        {
                            connection.Оборудование.Remove(equipmentToDelete);
                            connection.SaveChanges();

                            // Обновление данных в DataGrid
                            LoadEquipment();
                        }
                        else
                        {
                            MessageBox.Show("Оборудование не найдено.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите оборудование для удаления.");
            }
        }
    }
}