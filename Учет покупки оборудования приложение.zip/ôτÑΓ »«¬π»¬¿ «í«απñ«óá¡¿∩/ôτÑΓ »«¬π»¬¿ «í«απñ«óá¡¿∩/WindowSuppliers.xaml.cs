﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Учет_покупки_оборудования
{
    /// <summary>
    /// Логика взаимодействия для WindowSuppliers.xaml
    /// </summary>
    public partial class WindowSuppliers : Window
    {
        public WindowSuppliers()
        {
            InitializeComponent();
            LoadSuppliers();
        }

        private void Vihod_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        // Загрузка данных о поставщиках
        private void LoadSuppliers()
        {
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                dgAllSuppliers.ItemsSource = connection.Поставщики
                    .Select(p => new
                    {
                        p.id_поставщика,
                        p.наименование,
                        p.ИНН,
                        p.КПП,
                        p.адрес
                    })
                    .ToList();
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // Получаем данные из TextBox
            string name = tbName.Text;
            string inn = tbINN.Text;
            string kpp = tbKPP.Text;
            string address = tbAddress.Text;

            // Проверка ввода
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(inn) || string.IsNullOrEmpty(kpp) || string.IsNullOrEmpty(address))
            {
                MessageBox.Show("Заполните все поля.");
                return;
            }

            // Получение максимального существующего id_поставщика
            int maxId;
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                maxId = connection.Поставщики.Max(p => p.id_поставщика);
            }

            // Вычисление нового id_поставщика
            int newId = maxId + 1;

            // Добавление нового поставщика в базу данных
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                Поставщики newSupplier = new Поставщики()
                {
                    id_поставщика = newId,
                    наименование = name,
                    ИНН = inn,
                    КПП = kpp,
                    адрес = address
                };

                connection.Поставщики.Add(newSupplier);
                connection.SaveChanges();

                // Обновление данных в DataGrid
                LoadSuppliers();

                // Очистка полей
                tbName.Text = "";
                tbINN.Text = "";
                tbKPP.Text = "";
                tbAddress.Text = "";
            }
        }

        // Удаление выбранного поставщика
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            // Получение выбранной строки из DataGrid
            if (dgAllSuppliers.SelectedItem != null)
            {
                var selectedSupplier = dgAllSuppliers.SelectedItem as dynamic;
                int supplierId = selectedSupplier.id_поставщика;

                // Подтверждение удаления
                if (MessageBox.Show("Удалить поставщика?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    // Удаление поставщика из базы данных
                    using (УчетПОEntities connection = new УчетПОEntities())
                    {
                        var supplierToDelete = connection.Поставщики.Find(supplierId);
                        if (supplierToDelete != null)
                        {
                            connection.Поставщики.Remove(supplierToDelete);
                            connection.SaveChanges();

                            // Обновление данных в DataGrid
                            LoadSuppliers();
                        }
                        else
                        {
                            MessageBox.Show("Поставщик не найден.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите поставщика для удаления.");
            }
        }
    }
}