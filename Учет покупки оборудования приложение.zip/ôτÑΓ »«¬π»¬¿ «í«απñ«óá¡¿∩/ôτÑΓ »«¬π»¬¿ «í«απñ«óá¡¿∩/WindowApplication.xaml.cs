﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Учет_покупки_оборудования
{
    /// <summary>
    /// Логика взаимодействия для WindowApplication.xaml
    /// </summary>
    public partial class WindowApplication : Window
    {
        private int selectedApplicationId; // Хранит id выбранной заявки

        public WindowApplication()
        {
            InitializeComponent();
            LoadApplications();
            LoadSuppliers();
            LoadEmployees();
            LoadEquipment();
            dgAllApplication.SelectionChanged += dgAllApplication_SelectionChanged; // Добавляем обработчик SelectionChanged
        }

        private void Vihod_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        // Загрузка данных о заявках
        private void LoadApplications()
        {
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                dgAllApplication.ItemsSource = connection.Заявка
                    .Select(z => new
                    {
                        z.id_заявки,
                        z.дата,
                        Поставщик = z.Поставщики.наименование,
                        ОтветственныйСотрудник = z.Сотрудники.ФИО
                    })
                    .ToList();
            }
        }

        // Загрузка данных о поставщиках
        private void LoadSuppliers()
        {
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                cbSupplier.ItemsSource = connection.Поставщики.ToList();
                cbSupplier.DisplayMemberPath = "наименование";
                cbSupplier.SelectedValuePath = "id_поставщика";

                cbSupplier_Копировать.ItemsSource = connection.Поставщики.ToList();
                cbSupplier_Копировать.DisplayMemberPath = "наименование";
                cbSupplier_Копировать.SelectedValuePath = "id_поставщика";
            }
        }

        // Загрузка данных о сотрудниках
        private void LoadEmployees()
        {
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                cbSupplier_Копировать.ItemsSource = connection.Сотрудники.ToList();
                cbSupplier_Копировать.DisplayMemberPath = "ФИО";
                cbSupplier_Копировать.SelectedValuePath = "id_сотрудника";
            }
        }

        // Загрузка данных об оборудовании
        private void LoadEquipment()
        {
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                cbNameEquipment.ItemsSource = connection.Оборудование.ToList();
                cbNameEquipment.DisplayMemberPath = "наименование";
                cbNameEquipment.SelectedValuePath = "id_оборудования";
            }
        }

        // Добавление оборудования в список выбранного оборудования
        private void btnAddEquipment_Click(object sender, RoutedEventArgs e)
        {
            // Получаем данные из TextBox и ComboBox
            int? equipmentId = cbNameEquipment.SelectedValue as int?;
            int? quantity = int.TryParse(tbNumberOfEquipment.Text, out int parsedQuantity) ? (int?)parsedQuantity : null;
            decimal? price = decimal.TryParse(tbPrice.Text, out decimal parsedPrice) ? (decimal?)parsedPrice : null;

            // Проверка ввода
            if (equipmentId == null || quantity == null || price == null)
            {
                MessageBox.Show("Заполните все поля.");
                return;
            }

            // Проверка, выбрана ли заявка
            if (selectedApplicationId == 0)
            {
                MessageBox.Show("Выберите заявку.");
                return;
            }

            // Добавление нового оборудования в заявку
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                // Создаем новый объект "Оборудование в заявке"
                Оборудование_в_заявке newEquipmentInApplication = new Оборудование_в_заявке()
                {
                    id_заявки = selectedApplicationId,
                    id_оборудования = equipmentId.Value,
                    количество = quantity.Value,
                    цена = price.Value
                };

                connection.Оборудование_в_заявке.Add(newEquipmentInApplication);
                connection.SaveChanges();

                // Обновляем данные в DataGrid
                LoadEquipmentInApplication(selectedApplicationId);

                // Очистка полей ввода
                cbNameEquipment.SelectedItem = null;
                tbNumberOfEquipment.Text = "";
                tbPrice.Text = "";
            }
        }

        // Оформление заявки
        private void btnMakeAnApplication_Click(object sender, RoutedEventArgs e)
        {
            // Получаем данные из ComboBox и DatePicker
            int? supplierId = cbSupplier.SelectedValue as int?;
            DateTime? date = dpDateNow.SelectedDate;
            int? employeeId = cbSupplier_Копировать.SelectedValue as int?;

            // Проверка ввода
            if (supplierId == null || date == null || employeeId == null)
            {
                MessageBox.Show("Заполните все поля.");
                return;
            }

            // Получение максимального существующего id_заявки
            int maxId;
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                maxId = connection.Заявка.Max(z => z.id_заявки);
            }

            // Вычисление нового id_заявки
            int newId = maxId + 1;

            // Создание новой заявки
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                Заявка newApplication = new Заявка()
                {
                    id_заявки = newId, // Устанавливаем новый id_заявки
                    дата = date.Value,
                    id_поставщика = supplierId.Value,
                    id_ответственного_сотрудника = employeeId.Value
                };

                connection.Заявка.Add(newApplication);
                connection.SaveChanges();

                // Обновление данных в DataGrid
                LoadApplications();

                // Очистка полей
                cbSupplier.SelectedItem = null;
                dpDateNow.SelectedDate = null;
                cbSupplier_Копировать.SelectedItem = null;
                selectedApplicationId = 0;
                LoadEquipmentInApplication(0);
            }
        }

        // Удаление заявки
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            // Получение выбранной строки из DataGrid
            if (dgAllApplication.SelectedItem != null)
            {
                var selectedApplication = dgAllApplication.SelectedItem as dynamic;
                int applicationId = selectedApplication.id_заявки;

                // Подтверждение удаления
                if (MessageBox.Show("Удалить заявку?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                {
                    // Удаление заявки из базы данных
                    using (УчетПОEntities connection = new УчетПОEntities())
                    {
                        var applicationToDelete = connection.Заявка.Find(applicationId);
                        if (applicationToDelete != null)
                        {
                            connection.Заявка.Remove(applicationToDelete);
                            connection.SaveChanges();

                            // Обновление данных в DataGrid
                            LoadApplications();
                            selectedApplicationId = 0;
                            LoadEquipmentInApplication(0);
                        }
                        else
                        {
                            MessageBox.Show("Заявка не найдена.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите заявку для удаления.");
            }
        }

        // Загрузка оборудования для выбранной заявки
        private void LoadEquipmentInApplication(int applicationId)
        {
            using (УчетПОEntities connection = new УчетПОEntities())
            {
                dgSelectedEquipment.ItemsSource = connection.Оборудование_в_заявке
                    .Where(e => e.id_заявки == applicationId)
                    .Select(e => new
                    {
                        e.id_оборудования_в_заявке,
                        Наименование = e.Оборудование.наименование,
                        e.количество,
                        e.цена
                    })
                    .ToList();
            }
        }

        private void dgAllApplication_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Используем Dispatcher.BeginInvoke для вызова LoadEquipmentInApplication 
            // после обновления SelectedItem в dgAllApplication
            Dispatcher.BeginInvoke(new Action(() =>
            {
                if (dgAllApplication.SelectedItem != null)
                {
                    var selectedApplication = dgAllApplication.SelectedItem as dynamic;
                    selectedApplicationId = selectedApplication.id_заявки;
                    LoadEquipmentInApplication(selectedApplicationId);
                }
                else
                {
                    selectedApplicationId = 0;
                    LoadEquipmentInApplication(0);
                }
            }));
        }
    }
}