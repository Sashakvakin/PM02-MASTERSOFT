﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Учет_покупки_оборудования
{
    /// <summary>
    /// Логика взаимодействия для WindowAdmin.xaml
    /// </summary>
    public partial class WindowAdmin : Window
    {
        public WindowAdmin()
        {
            InitializeComponent();
        }

        private void Vihod_Click(object sender, RoutedEventArgs e)
        {
            MainWindow Windowmain = new MainWindow();
            Windowmain.Show();
            this.Close();
        }

        private void btnAddDevice_Click(object sender, RoutedEventArgs e)
        {
            WindowEquipment windowEquipment = new WindowEquipment();
            windowEquipment.Show();
            this.Close();
        }

        private void btnSuppliers_Click(object sender, RoutedEventArgs e)
        {
            WindowSuppliers windowSuppliers = new WindowSuppliers();
            windowSuppliers.Show();
            this.Close();
        }

        private void btnApplication_Click(object sender, RoutedEventArgs e)
        {
            WindowApplication windowApplication = new WindowApplication();
            windowApplication.Show();
            this.Close();
        }

        private void btnAccounation_Click(object sender, RoutedEventArgs e)
        {
            WindowAccountant accountantWindow = new WindowAccountant();
            accountantWindow.Show();
            this.Close();
        }
    }
}
