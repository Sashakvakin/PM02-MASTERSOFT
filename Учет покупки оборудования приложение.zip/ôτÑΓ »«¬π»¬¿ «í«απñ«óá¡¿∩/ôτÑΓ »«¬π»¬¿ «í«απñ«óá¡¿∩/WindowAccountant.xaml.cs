﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;

namespace Учет_покупки_оборудования
{
    /// <summary>
    /// Логика взаимодействия для WindowAccountant.xaml
    /// </summary>
    public partial class WindowAccountant : Window
    {
        public WindowAccountant()
        {
            InitializeComponent();
        }

        private void Vihod_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void btnGenerateReport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Получаем даты начала и конца периода
                DateTime startDate = dpDateStart.SelectedDate.Value;
                DateTime endDate = dpDateEnd.SelectedDate.Value;

                // Проверка ввода
                if (startDate > endDate)
                {
                    MessageBox.Show("Дата начала периода должна быть раньше даты конца периода.");
                    return;
                }

                // Создание отчета
                using (УчетПОEntities connection = new УчетПОEntities())
                {
                    var reportData = connection.Оборудование_в_заявке
                        .Where(oe => oe.Заявка.дата >= startDate && oe.Заявка.дата <= endDate)
                        .Select(oe => new
                        {
                            oe.Заявка.id_заявки,
                            oe.Заявка.дата,
                            oe.Оборудование.наименование,
                            oe.количество,
                            oe.цена
                        })
                        .OrderBy(oe => oe.дата)
                        .ToList();

                    // Отображаем отчет в DataGrid
                    dgReport1.ItemsSource = reportData;

                    // Настройка столбцов DataGrid
                    dgReport1.Columns.Clear(); // Очищаем существующие столбцы

                    dgReport1.Columns.Add(new DataGridTextColumn
                    {
                        Header = "Номер заявки",
                        Binding = new Binding("id_заявки"),
                        Width = 100
                    });

                    dgReport1.Columns.Add(new DataGridTextColumn
                    {
                        Header = "Дата",
                        Binding = new Binding("дата"),
                        Width = 100
                    });

                    dgReport1.Columns.Add(new DataGridTextColumn
                    {
                        Header = "Оборудование",
                        Binding = new Binding("наименование"),
                        Width = 200
                    });

                    dgReport1.Columns.Add(new DataGridTextColumn
                    {
                        Header = "Количество",
                        Binding = new Binding("количество"),
                        Width = 100
                    });

                    dgReport1.Columns.Add(new DataGridTextColumn
                    {
                        Header = "Стоимость",
                        Binding = new Binding("цена"),
                        Width = 100
                    });

                    // Вычисляем общую сумму
                    decimal totalSum = connection.Оборудование_в_заявке
                    .Where(oe => oe.Заявка.дата >= startDate && oe.Заявка.дата <= endDate)
                    .Sum(oe => oe.количество * oe.цена) ?? 0;

                    // Отображаем общую сумму в tbSum с двумя знаками после запятой
                    tbSum.Text = totalSum.ToString("N2");


                    // Создание диаграммы
                    var chartData = connection.Оборудование_в_заявке
                        .GroupBy(oe => oe.Оборудование.наименование)
                        .Select(g => new
                        {
                            Label = g.Key, // Наименование оборудования
                            Value = g.Sum(oe => oe.количество * oe.цена) // Сумма за оборудование
                        })
                        .ToList();
                }
            }
            catch
            {
                    MessageBox.Show("Пожалуйста, выберите начальную и конечную даты.");
            }
        }
    }
}