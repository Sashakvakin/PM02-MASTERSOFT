﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Учет_покупки_оборудования
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = tbLogin.Text;
            string password = tbPassword.Password;

            using (УчетПОEntities connection = new УчетПОEntities())
            {
                // Получаем пользователя по логину и паролю
                var user = connection.Авторизация
                    .Where(u => u.логин == username && u.пароль == password)
                    .Select(u => new
                    {
                        u.id_авторизации
                    })
                    .FirstOrDefault();

                if (user != null)
                {
                    // Получаем данные о сотруднике по id_авторизации
                    var employee = connection.Сотрудники.FirstOrDefault(s => s.id_авторизации == user.id_авторизации);

                    if (employee != null)
                    {
                        // Проверяем роль и открываем соответствующее окно
                        switch (employee.должность)
                        {
                            case "Менеджер по закупкам":
                                WindowEmployee employeeWindow = new WindowEmployee();
                                employeeWindow.Show();
                                this.Close();
                                break;
                            case "Бухгалтер":
                                WindowAccountant accountantWindow = new WindowAccountant();
                                accountantWindow.Show();
                                this.Close();
                                break;
                            case "Администратор":
                                WindowAdmin adminWindow = new WindowAdmin();
                                adminWindow.Show();
                                this.Close();
                                break;
                            default:
                                MessageBox.Show("Неизвестная роль пользователя.");
                                break;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Пользователь не найден.");
                    }
                }
                else
                {
                    MessageBox.Show("Неверный логин или пароль.");
                }
            }
        }
    }
}